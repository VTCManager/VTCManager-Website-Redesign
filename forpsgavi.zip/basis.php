<!DOCTYPE html>
<html lang="de">
  <head>
	  <title>Title - VTCManager</title>
	  <?php include 'basis_header.php'; ?>  
  </head>
  <body>
	  <?php include 'navbar.php'; ?>  
	      <footer class="footer">
        <div class="container">
            <div class="col-md-9 social-media">
                <p class="pull-left">
                    <a href="https://vtc.northwestvideo.de/impressum">Impressum</a>|
                    <a href="https://vtc.northwestvideo.de/datenschutz">Datenschutz &amp; Nutzungsbedingungen</a>
                </p>
            </div>
            <div class="col-md-3">
                <p class="pull-right">© Joschua Haß 2019</p>
            </div>
                    </div>
    </footer>
  </body>
</html>
